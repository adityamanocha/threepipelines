package it;

import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class CalculatorIT {
	WebDriver driver;
	WebElement element;

	@Test
	public void valid_UserCredential() {
		
		System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://localhost:8063/calculator");
		//driver.findElement(By.xpath(".//*[@id='signin']")).click();
		driver.findElement(By.id("log")).clear();
		driver.findElement(By.id("pwd")).clear();

		driver.findElement(By.id("log")).sendKeys("admin");
		driver.findElement(By.id("pwd")).sendKeys("admin");
		driver.findElement(By.id("login")).click();

		try {
			element = driver.findElement(By.id("ls"));
		} catch (Exception e) {
		}
		Assert.assertNotNull(element);
		System.out.println("Ending test " + new Object() {
		}.getClass().getEnclosingMethod().getName());
		driver.quit();
	}

	@Test
	public void inValid_UserCredential() {
		
		System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://localhost:8063/calculator");
		
		
		driver.findElement(By.id("log")).clear();
		driver.findElement(By.id("pwd")).clear();

		driver.findElement(By.id("log")).sendKeys("a");
		driver.findElement(By.id("pwd")).sendKeys("x");
		driver.findElement(By.id("login")).click();

		try {
			element = driver.findElement(By.id("ep"));
		} catch (Exception e) {
		}
		Assert.assertNotNull(element);
		System.out.println("Ending test " + new Object() {
		}.getClass().getEnclosingMethod().getName());
		driver.quit();
	}

	
}
